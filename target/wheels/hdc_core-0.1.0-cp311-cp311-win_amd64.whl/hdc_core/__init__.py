from .hdc_core import *

__doc__ = hdc_core.__doc__
if hasattr(hdc_core, "__all__"):
    __all__ = hdc_core.__all__